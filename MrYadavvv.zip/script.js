// script.js
document.getElementById('clickButton').addEventListener('click', function() {
    alert('Button clicked!');
});
